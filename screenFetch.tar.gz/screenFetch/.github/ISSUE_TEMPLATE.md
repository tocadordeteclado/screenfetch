<!--
  - PREENCHA AS SEGUINTES INFORMAÇÕES.
 -->

**Estou enviando um ...**  (verifique um com "x")
```
[ ] relatório de falha.
[ ] pedido de nova distro.
```

**Bug report**
```
=> pesquise no git por um problema semelhante ou PR antes de enviar.
=> baixe a revisão mais recente do Git e verifique se a falha ainda está presente.
   -> https://localhost/screenFetch/
=> Mostre-nos a saída de: screenfetch -v
```

**Nova solicitação de distribuição**
```
Nome da distro: 
Pagina inicial: 
Logotipo da distribuição: 
Gerenciador de plug's: 

Mostre-nos a saída de
 => lsb_release -sirc
 => cat /etc/os-release
 => ls -1 /etc/*-release
```

